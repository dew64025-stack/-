# Task 2 实现与验证报告

基线：`05df499ffe6c985ec9ec7e0c8d0540e7d2f2b9cd`，分支 `feature/backend-server`。实现于2026-10-13，恢复、自查及最终验证于2026-10-14。范围为 Task2 brief 的会话、动态身份、权限、持久幂等、游标、限流与 HTTP 安全边界。未推送 GitHub，未修改 V1～V6，未实现后续业务或学校官方验证器。

## 结果与文件

新增 `backend/src/main/java/com/caizhitong/security/`：

- `Actor.java`、`ActorLoader.java`、`DatabaseActorLoader.java`、`CurrentActor.java`：服务器数据库身份和动态能力读取。
- `SessionKind.java`、`SessionTokens.java`、`SessionRecord.java`、`SessionStore.java`、`SessionTokenService.java`、`RedisSessionStore.java`：namespace隔离的随机opaque凭据、摘要存储、Lua轮换与撤销。
- `RolePermissions.java`、`RoutePolicy.java`、`BearerSessionFilter.java`、`FilterErrors.java`：静态角色矩阵、精确路由策略、Bearer解析及安全错误包装。

新增 `backend/src/main/java/com/caizhitong/common/idempotency/`：`BusinessWrite.java`、`BusinessWriteConfiguration.java`、`IdempotencyContext.java`、`IdempotencyFilter.java`、`IdempotencyExecutor.java`。

新增 `backend/src/main/java/com/caizhitong/common/pagination/`：`CursorPayload.java`、`CursorCodec.java`、`PageLimits.java`。

新增 `backend/src/main/java/com/caizhitong/common/ratelimit/`：`RateCounter.java`、`RedisRateCounter.java`、`RateLimiter.java`。

修改 `backend/src/main/java/com/caizhitong/config/SecurityConfiguration.java`、`backend/src/main/resources/application.yml`、`backend/README.md`、`DATABASE.md`。新增 `sql/V7__runtime_coordination.sql`。未新增Maven依赖。

新增测试：`security/OpaqueSessionTest.java`、`CurrentActorTest.java`、`DatabaseActorLoaderTest.java`、`SessionHttpBoundaryTest.java`；`common/idempotency/IdempotencyExecutorTest.java`及`support/MysqlDateTimeDataSource.java`；`common/pagination/CursorCodecTest.java`；`common/ratelimit/RateLimiterTest.java`。所有远程store替身、测试身份、HTTP探针和驱动形状替身仅在 `src/test`。

主代理修改的 `docs/backend/identity-security-decisions.md` 和 `docs/superpowers/plans/2026-10-13-backend-server.md` 不属于本任务提交。

## 公共接口与接入边界

- `Actor(long userId,long campusId,Set<String> permissions,boolean phoneBound,boolean studentVerified,String status,SessionKind kind)`，`ActorLoader.load(long,long,SessionKind): Optional<Actor>`。
- `CurrentActor.optional()` 返回当前数据库重载身份；`requireAuthenticatedIdentity()`只证明有效身份。`require()`拒绝非active，`requireStudent()`进一步要求STUDENT、现行手机号授权和verified认证；`requirePermission(code)`要求ADMIN及当前权限。
- `SessionTokenService.issue/authenticate/refresh/revoke`及`SessionTokens(accessToken,expiresIn,refreshToken,refreshExpiresIn)`符合brief接口；authenticate未知或过期凭据返回empty，HTTP转401。refresh和revoke无效凭据401，Redis异常503且retryable。access900秒、refresh604800秒，32字节SecureRandom/base64url；SessionTokens.toString不输出凭据。Redis值只包含摘要、身份、kind和sessionId，不存角色/权限/原始凭据。
- `CursorPayload(String scope,Map<String,String> sortKeys)`；`CursorCodec.encode/decode`采用带用途HMAC和规范base64url，拒绝篡改、跨scope、非法base64及超过4096字符。scope必须由查询服务从服务器校园和规范化过滤条件组成。`PageLimits.resolve(null)=20`，1～100。
- `@BusinessWrite(permission="...",student=true,ownRights=true)`三个属性独立使用，ownRights与另两个不能组合。通过Spring基础设施advisor实现，无新增AspectJ依赖。方法返回具体业务DTO，不允许ApiResponse、SessionTokens、Object、集合、Map、数组或primitive。
- `IdempotencyExecutor.execute(IdempotencyContext,Class<T>,Runnable authorize,Supplier<T> action)`：权限回调在重放前运行。namespace/user/campus/method/真实URI与key摘要隔离；同键异摘要409；pending409/retryable；锁等待等暂时性数据库异常503/retryable。唯一记录占位、业务动作和加密DTO结果在同一业务数据源事务内提交/回滚，失败不被捕获后强行提交。
- `IdempotencyFilter`只校验请求头并绑定规范化JSON/查询参数摘要，缓存体供Controller正常反序列化；不在HTTP结束后另存业务响应。业务写请求体上限1MiB。记录保存24小时，过期后允许新命令；持久业务唯一性仍需业务表约束。
- `RateLimiter.check(String bucket,int max,Duration window)`使用Redis Lua `INCR`和首次`PEXPIRE`原子计数，429或503均retryable。bucket由服务端调用方选定。

Controller必须调用外部Spring代理服务，不能通过同类内调用、private/final写方法、Controller直接写数据库、其他数据源或REQUIRES_NEW业务动作绕开事务边界。对象归属/当前可见性检查应在Controller、`@PreAuthorize`或明确授权回调中执行，不能只放在被重放跳过的方法体内。外层ApiResponse由Controller重新包装当前requestId，ID转字符串，不采用全局Long序列化。

## 安全规则落实

学生和后台使用独立链。只解析Bearer；学生token不能通过后台链。公开GET限文档P/P-L精确路径，未实现路径404，不能因公开GET放开同路径POST。认证/refresh/phone/logout、后台认证/MFA/reauth以及明确临时凭据路径使用固定幂等例外，客户端不能声明例外；凭据例外不能进入持久业务缓存。

精确公开边界包括 `GET /campus-issues/{id}`、`GET /mutual-aid/posts/{id}`，以及按最新裁定继承帖子可见权限的 `GET /mutual-aid/posts/{id}/ratings`。只允许数字ID和精确GET；子路径、evidences/private和POST不因此开放。Task8/9查询必须校验同校园、已审核公开/本人归属；对无权者未审核、私密或跨校对象返回404。这是路由层入口允许，不能当成对象公开授权。

后台认证入口保持denyAll，等待Task3真实凭据与MFA。后台CSRF开启，CSRF Cookie Secure/HttpOnly/SameSite=Strict，独立cookie/header名称。临时二进制上传入口保持关闭，Task4须安装独立上传凭据验证。默认其他路径与Actuator拒绝，无生产默认账号或测试宽松fallback。

受限身份仍可被验证，但普通业务403；仅精确的GET本人处罚/申诉/数据请求，POST本人申诉/导出/注销/数据请求取消进入ownRights白名单。没有宽泛/me放行；对象归属还须后续业务服务检查。缺失/已删除用户或已撤销会话始终拒绝。

phoneBound要求verified手机号和最新phone授权status=granted且revoked_at为空；授权按created_at、id倒序取最新，新的revoked覆盖旧granted。管理员角色从roles/user_roles参数化native SQL读取；非管理员角色不能进入ADMIN，异校角色不授予本校权限。平台级角色仅接收明确platform_admin/security_investigator；并不提供任意跨校身份能力。campus_admin/platform_admin不会自动获得security.investigate。

## RED → GREEN 实际证据

工具链，以下命令均在 `C:/Users/19683/source/repos/caizhitong/backend` 执行：

```powershell
$env:JAVA_HOME='C:/Users/19683/AppData/Local/caizhitong-devtools/jdk-21.0.12.1+1'
# 下文 mvn.cmd 为以下实际路径：
# C:/Users/19683/AppData/Local/caizhitong-devtools/apache-maven-3.9.16/bin/mvn.cmd
```

2026-10-13 初次 `mvn.cmd '-Dtest=OpaqueSessionTest,CurrentActorTest,CursorCodecTest,RateLimiterTest' test`，先出现缺失接口的编译失败；随后创建只有声明/空行为的最小骨架，再运行相同命令。实际行为RED：`Tests run: 12, Failures: 6, Errors: 6, Skipped: 0; BUILD FAILURE`。例如限流应抛429/503却未抛异常、角色权限应含调查权限却为空；会话及游标未实现方法产生UnsupportedOperationException。这里明确区分缺失接口编译错误和执行阶段未实现行为。实现后同一命令GREEN：`12,0,0,0; BUILD SUCCESS`（20:20:54）。

`mvn.cmd '-Dtest=IdempotencyExecutorTest' test`，最小executor返回null时RED：`Tests run: 5, Failures: 5, Errors: 0; BUILD FAILURE`（20:22:28）。真实H2事务中业务记录应1实际0、异请求/撤权/业务异常应抛却未抛。实现后相同命令GREEN：`5,0,0,0; BUILD SUCCESS`（20:23:54）。

新增HTTP安全及受限身份测试后，`mvn.cmd '-Dtest=SessionHttpBoundaryTest,CurrentActorTest' test` RED：`11 tests,5 failures,2 errors; BUILD FAILURE`（20:26:06）；公开GET预期404实际401、有效admin CSRF预期200实际401、学生写缺key预期400实际403、受限身份被错误抹除。完成安全链和身份能力后，`mvn.cmd '-Dtest=SessionHttpBoundaryTest,CurrentActorTest,OpaqueSessionTest,IdempotencyExecutorTest' test` GREEN：`20,0,0,0; BUILD SUCCESS`（20:32:36）。

手机号现行授权测试：`mvn.cmd '-Dtest=DatabaseActorLoaderTest' test` RED：`3 tests,1 failure,0 errors`（20:34:05），无当前授权phoneBound应false实际true。改参数化数据库查询后，`mvn.cmd '-Dtest=DatabaseActorLoaderTest,SessionHttpBoundaryTest' test` GREEN：`9,0,0,0; BUILD SUCCESS`（20:34:49）。

生命周期补充：`mvn.cmd '-Dtest=OpaqueSessionTest,IdempotencyExecutorTest,SessionHttpBoundaryTest' test` 22tests/2failures（20:37:08）；未知logout未返回401，MockMvc Set-Cookie字符串省略SameSite扩展属性。通过本地Spring Security字节码核实Cookie.setAttribute写入；测试改为直接验证真实Cookie对象属性，保留匹配/错误csrf header的200/403检查，未削弱生产Cookie配置。`mvn.cmd '-Dtest=OpaqueSessionTest,IdempotencyExecutorTest,SessionHttpBoundaryTest,RateLimiterTest' test` GREEN：`24,0,0,0; BUILD SUCCESS`（20:39:08）。

凭据/结果类型与规范base64补充：`mvn.cmd '-Dtest=IdempotencyExecutorTest,CursorCodecTest' test` RED：`11 tests,2 failures,0 errors`（20:40:45），generic缓存未拒绝，改变签名base64未使用位仍被接受。实现拒绝后相同命令GREEN：`11,0,0,0; BUILD SUCCESS`（20:41:47）。

2026-10-13 `mvn.cmd package` 完整首次GREEN：`Tests run: 56, Failures: 0, Errors: 0, Skipped: 0; BUILD SUCCESS`（20:42:07）。

### 2026-10-14 DATETIME / UTC 修正

自查本地Connector/J 9.7.0的ResultSetImpl及Spring JDBC 7.0.9 JdbcUtils字节码：不带目标类型的DATETIME getObject可能返回LocalDateTime，queryForMap不将其自动变成Timestamp。原executor强转Timestamp会在真实驱动形状下失败。

测试替身 `MysqlDateTimeDataSource` 仍使用真实H2连接和事务，只将expires_at的无类型getObject暴露为LocalDateTime；不伪造SQL写入/事务结果。

```powershell
mvn.cmd '-Dtest=IdempotencyExecutorTest#mysqlDatetimeLocalDateTimeMappingReplaysWithoutTimestampCast' test
```

RED（12:51:06）：`Tests run: 1, Failures: 0, Errors: 1; BUILD FAILURE`，实际错误 `ClassCastException: java.time.LocalDateTime cannot be cast to java.sql.Timestamp`，发生于IdempotencyExecutor过期时间检查。随后使用显式typed RowMapper、`getObject("expires_at", LocalDateTime.class)`，以ZoneOffset.UTC解释数据库DATETIME；created/expires写入也使用UTC LocalDateTime，避免依赖JVM默认时区。

```powershell
mvn.cmd '-Dtest=IdempotencyExecutorTest' test
```

GREEN（12:51:54）：`Tests run: 9, Failures: 0, Errors: 0, Skipped: 0; BUILD SUCCESS`。包含并发、回滚、重放及上述驱动形状回归。该证据不是运行中的MySQL集成测试。

## 最终全量验证

2026-10-14按主代理接口对照补充公开详情与评价边界。`mvn.cmd '-Dtest=SessionHttpBoundaryTest#onlyDocumentedPublicGetsReach404AndOtherMethodsRemainClosed' test`：问题/互助详情RED为1test/1failure/0errors（12:56:11），预期404实际401；修正后 `mvn.cmd '-Dtest=SessionHttpBoundaryTest' test` GREEN为8/0/0/0（12:56:48）。补ratings继承规则后同一聚焦方法再次RED为1/1/0（12:57:30），预期404实际401；只增加精确ratings GET后完整HTTP组GREEN为8/0/0/0（12:58:04）。测试同时否定任意子路径及同路径POST，未使用通配放行。

DATETIME修正后的首次完整package（12:52:29）为57/0/0/0；随后因新公开路由改动再次执行 `mvn.cmd package`，包含全量test及Spring Boot repackage，12:58:24结束，exit0：

```text
Tests run: 57, Failures: 0, Errors: 0, Skipped: 0
Building jar: .../backend/target/backend-0.0.1-SNAPSHOT.jar
BUILD SUCCESS
Total time: 11.100 s
```

Task2新增37个测试：Idempotency9、Cursor3、RateLimiter2、CurrentActor5、DatabaseActorLoader3、OpaqueSession7、SessionHttpBoundary8；原Task1测试20。实际H2事务验证同key同输入只执行一次、冲突409、失败业务和记录同时回滚、撤权拒绝重放、数据库唯一记录并发串行、校园/namespace/路由/方法隔离、pending可重试、超期新执行。

完整运行仅保留Task1已记录的预期负向启动WARN（业务账号/迁移账号相同被拒绝）；Task2 advisor改用懒加载ObjectProvider，已消除它引入的BeanPostProcessor过早初始化WARN。没有把原Task1无意义denyAll403当作CSRF证据；新增HTTP测试明确对比缺失/错误/有效CSRF，并走真实cookie/header匹配。

归档检查使用PowerShell ZipFile和SHA256：生产JAR中V1～V7均与源SQL逐字节一致，无H2 jar、application-test、demo种子或测试store/探针/驱动替身类；`git diff --check`通过，V1～V6 git diff为空。归档输出为七次Equal=true、ExcludedEntries=0；最终XML累计Tests=57、Failures=0、Errors=0、Skipped=0。

## 未执行的外部验收与注意事项

没有运行中的真实MySQL/Redis；未执行MySQL Flyway V1～V7、复合FK/账号授权、真实MySQL锁超时/并发，也未执行Redis Lua/EVALSHA TTL/并发刷新/撤销/限流窗口集成。Redis并发测试只证明SessionTokenService与同步测试store的协作，不能称为真实Redis并发实测。DATETIME替身也不替代MySQL驱动连接实测。

外部验收仍需：迁移副本执行V1～V7并逐表授权；用业务账号验证跨校园FK拒绝及加密重放/回滚/锁冲突；真实Redis验证access/refresh TTL、两个并发刷新恰一成功、旧access失效、刷新凭据登出、窗口重置、断开Redis返回503；生产HTTPS后台验证CSRF cookie交付和Task3凭据/MFA流程。

Task3须创建当前phone授权且与验证号码一起提交，普通验证不能仅靠student role。Task3后台认证必须先验证真实密码/MFA再调用ADMIN issue，JSON中的admin refreshToken仍按API为空并通过安全Cookie交付。TokenService返回凭据只服务认证交付，不得进入普通业务DTO或持久幂等结果、日志。

Task4须替换当前关闭的二进制上传入口为独立临时凭据链，不能简单permitAll或以Bearer代替上传凭据。后续业务模块必须使用上述事务、授权回调和明确DTO边界，不能把远程微信/AI/扫描放进幂等数据库事务。跨校管理员操作仍须显式授权scope，本任务未提供任意跨校会话切换。

本地报告位于忽略的SDD目录，不进入生产包或代码提交。本地checkpoint commit：`5d8112b5e808b7c774566d26fd011caecfc4b505`，标题 `feat: add opaque sessions and transactional runtime coordination`。提交38个Task2文件；父代理的三份docs仍保持未提交修改。没有远程推送。

## 独立审查修复轮 1/5：刷新与撤销交错不得假成功

审查基线为 `5d8112b5e808b7c774566d26fd011caecfc4b505`。Important问题经代码和确定性测试确认：revoke先读旧record，refresh原子轮换删除旧key并建立新key，旧revoke的Lua不再匹配，却原来无条件返回1；adapter忽略结果，HTTP错误报告revoked=true。

本轮仅保证原子撤销结果正确，不扩大为跨轮换代际或多设备全部登出。刷新先完成后，旧凭据的撤销返回401；新凭据仍有效，调用方可用当前凭据明确撤销。正常撤销同时删除该代际access/refresh。

修改清单：

- `security/RedisSessionStore.java`：Lua只有实际匹配并DEL时返回1，不匹配返回0；adapter将1映射true、0映射false，null仍为存储错误。
- `security/SessionStore.java`：`void revoke(SessionRecord)`改为`boolean revoke(SessionRecord)`，只在原子匹配并撤销时为true。这是内部store契约变化，公开`SessionTokenService.revoke(String,SessionKind)`签名不变。
- `security/SessionTokenService.java`：检查boolean，false抛401/UNAUTHENTICATED，不再向调用方报告撤销成功；存储异常仍503/retryable。
- `security/OpaqueSessionTest.java`：所有store替身同步契约。新增test-only回调安排“读旧记录→刷新完成→执行撤销”的确定性顺序，验证401、新代际仍有效、当前access可正常撤销并使refresh失效。
- 新增 `security/RedisSessionStoreTest.java`：实际生产RedisSessionStore/SessionTokenService，替换网络边界StringRedisTemplate的execute结果，验证Redis返回0向上传递为401，1正常完成，null为503。不是只测试内存替身。
- `security/SessionHttpBoundaryTest.java`：测试专用logout入口展示安全401包装；成功刷新后的当前refresh正常logout返回revoked=true，并验证当前access/refresh随之失效。入口和交错回调仅存在于src/test，未新增生产认证fallback。

RED先于生产修改，2026-10-14运行：

```powershell
mvn.cmd '-Dtest=OpaqueSessionTest#rotationBetweenLogoutReadAndAtomicRevokeMustReturn401RatherThanFalseSuccess,RedisSessionStoreTest,SessionHttpBoundaryTest#interleavedRefreshAndLogoutReturns401AndCurrentCredentialsCanLogoutNormally' test
```

13:10:18结束，exit1，实际输出：`Tests run: 4, Failures: 3, Errors: 0, Skipped: 0; BUILD FAILURE`。两处服务测试均为 `Expected BusinessException to be thrown, but nothing was thrown`；HTTP交错 `Status expected:<401> but was:<200>`，响应错误包含`data.revoked=true`。这证实服务和真实Redis adapter都吞掉了原子比较失败。

修正Lua、契约及服务层后运行：

```powershell
mvn.cmd '-Dtest=OpaqueSessionTest,RedisSessionStoreTest,SessionHttpBoundaryTest' test
```

13:11:15结束，exit0：`Tests run: 19, Failures: 0, Errors: 0, Skipped: 0; BUILD SUCCESS`。Opaque8、RedisSessionStore2、SessionHttpBoundary9，包含正常access/refresh撤销、过期access仍用有效refresh登出及确定性交错。

随后运行 `mvn.cmd package`，13:12:25结束，exit0：

```text
Tests run: 61, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
Total time: 12.163 s
```

XML累计61/0/0/0；归档ExcludedEntries=0、V1～V7七次Equal=true、暂存diff --check通过。本轮未修改SQL/权限/三份父代理docs；无新依赖。Lua源码分支已核对，adapter返回值通过生产调用链测试，但没有运行真实Redis Lua或真实MySQL，本轮不能称为Redis并发实测。真实Redis交错仍为外部验收项。本轮本地checkpoint：`4e1d8b0dc430dc3244d1a74d1a3cf92bc3730eb0`，标题 `fix: reject unmatched session revocation`，六个文件；仅本轮审查diff为 `5d8112b5e808b7c774566d26fd011caecfc4b505..4e1d8b0dc430dc3244d1a74d1a3cf92bc3730eb0`。没有远程推送。
