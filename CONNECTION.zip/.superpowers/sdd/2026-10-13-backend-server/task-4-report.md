# Task4 安全文件与材料报告

- BASE: 4fad46addeb98a9db21d10360b481cca35fd611f；分支 feature/backend-server。
- 状态：DONE_WITH_CONCERNS。Task4范围实现、聚焦与全套/真实文件链路验证完成；真实MySQL和旧数据转换按下文列为未验收，等待主控独立审查。仅本地提交，不push；本报告保持ignored。
- 没有连接现有MySQL84、修改V1–V8、访问D:/project或读取真实.env。没有更改主控容器/配置/文档，没有派子agent。

## 16路由矩阵

所有路径前缀/api/v1；ID及外键均以字符串返回，数字大小/版本保持数字。正常写请求由外部Spring代理执行，所有者检查在重放前。

| 方法 | 路由 | 已实现边界 |
| --- | --- | --- |
| POST | /materials/upload-intents | STUDENT登录，purpose固定material，严格类型/大小/MIME/名称/可选摘要 |
| POST | /files/upload-intents | STUDENT登录；avatar只图，业务用途重新检查现行学生/手机状态 |
| POST | /files/uploads/{uploadId} | 独立Upload安全链；32字节随机凭据摘要；用户/校园/namespace/用途绑定，10分钟、原子单次领取；只允许一个file part |
| POST | /files/uploads/{uploadId}/complete | 本人STUDENT；幂等代理内原子创建attachment及scan job，其他键重试也不重复登记 |
| GET | /files/{attachmentId} | 本人或明确关联业务策略；同校园不是授权；不返回objectKey |
| POST | /files/{attachmentId}/download-url | 当前授权且clean，120秒签名；不进持久幂等缓存 |
| POST | /materials | 本人同校园clean material附件，创建不可变首版本 |
| GET | /materials | 本人范围，q/tag，绑定过滤与校园/用户的签名游标，limit上限复用PageLimits |
| GET | /materials/{id} | 所有者与校园，Material字段及versions |
| POST | /materials/{id}/update | 所有者在重放前检查，版本冲突拒绝，仅expiresAt/tags |
| POST | /materials/{id}/versions | 所有者及新clean附件预授权，追加新版本，不UPDATE旧版本 |
| DELETE | /materials/{id} | 严格version，检查清单/usage/growth/保留策略，软删除并同事务登记清理 |
| POST | /admin/files/upload-intents | ADMIN+CSRF+file.upload；名单另需identity.import，通知另需notice.write |
| POST | /admin/files/uploads/{uploadId}/complete | ADMIN+CSRF+file.upload+本人namespace，重放前重新授权 |
| GET | /admin/files/{attachmentId} | ADMIN+file.read且本人/实际业务归属，名单不暴露内容 |
| POST | /admin/files/{attachmentId}/download-url | ADMIN+CSRF+file.read+业务归属；名单另需identity.import且先写审计 |

管理员二进制也只走统一/files/uploads入口，凭据从后台意向绑定ADMIN；不能用Bearer或STUDENT会话冒充。原公开路径集合未扩大。

## 共享窄接口与身份交接

- IdentityFiles保留原三个方法，唯一生产Bean为IdentityFileAccess，删除默认全503占位Bean；没有多个模糊生产实现。
- validateAvatar/validateRoster/roster验证当前身份、校园、所有者、namespace、用途、active和clean；名单再次读取授权、有界且核对内容散列。
- AvatarUrls是单独URL水合接口：IdentityService.userResponse在业务代理之外以avatar_attachment_id生成短签；GET /me也使用。写DTO保持avatarUrl=null；测试解密实际幂等记录，确认没有signature字符串，users.avatar_url未保存签名。
- AttachmentService.owner供写关联前检查；readCleanOwner给有界原始业务读取；LinkedAttachmentPolicy只为后续真实关联对象策略提供桥，默认没有泛化校内授权。material/avatar/student_roster拒绝该泛化策略。
- MaterialRetentionPolicy供后续历史/AI模块登记保留义务。现存checklist_items、material_usage_records、growth_records已直接检查。共享附件在同一附件锁下重新查其他有效材料引用，多个附件按ID排序锁定。
- 实际StudentRosterWorker已通过真实IdentityFiles读取clean私密CSV并写入student_roster；跨namespace/跨校园/撤销权限负例保留。名单不是自动学生认证提供器。
- 每个具体业务对象最多9张业务图片，须由后续业务对象关联入口执行；单文件上传路由没有客户端批量图片集合。未声称现有文件模块能替代业务对象的数量校验。

## 实现与安全自查

- UploadService：短事务登记意向与原子领取；流式BoundedDigestStream到S3隔离对象，超限停止，原始摘要与声明一致后才置uploaded。领取前同事务登记孤儿清理，远程IO不持有业务数据库事务。
- UploadCompletionService：完成登记与scan job同事务，复用V8 campus_id/owner_user_id/access_domain/claim_token，只新增可信file_attachment_id。不靠payload.userId授予访问；旧未知归属不猜。
- FileScanWorker：5分钟租约、3次尝试、30秒重试、claim token fencing。先核对原始长度/散列，再真实扫描原始字节，然后格式校验/重编码。只有两项都通过才clean；原始SHA和content SHA分开保存。图片候选对象先登记清理；失败/失去租约留下可回收任务。
- FileCleanupWorker：对象删除在事务外；失败持久重试；不删除仍由active附件引用的同一键。材料变更和清理登记原子一致。保留版本行与旧内容直至满足删除义务。
- JPEG/PNG检查魔数、真实读取器、先尺寸后解码、2500万像素，默认重编码去元数据；PDFBox真实解析且<=500页；DOCX中央目录及CRC、1000条/64MiB总/20MiB单条/100压缩比，拒绝路径穿越/重复/加密/宏与外部关系，XML禁止DTD/实体。
- ClamdScanner：Java Socket INSTREAM，connect 2s/read 30s/4KiB回应上限；额外32s整体截止关闭阻塞IO；只有本次精确stream: OK是CLEAN，FOUND为INFECTED，未知/ERROR/EOF/超限失败。
- 生产ObjectStorage是实际S3客户端，ClamD是实际网络协议，缺配置failclosed。S3固定端点、禁HTTP重定向，无HTTP trace/签名URL日志；Controller无存储密钥。
- 新对象键只存AES-GCM密文；材料版本绑定附件和内容散列，只INSERT。旧明文列由V9保留为可空，不自动删除/伪装迁移成功。
- 新增依赖为brief允许的minio9.0.3/pdfbox3.0.8；另显式声明minio POM所需okhttp-jvm5.3.2，因为OkHttp5的Maven多平台空壳不包含JVM类。已通知主控并向用户说明；没有切换S3服务端或新增框架。

## 变更文件

新增生产：material/files下AttachmentScope、LinkedAttachmentPolicy、AttachmentService、AvatarUrls、IdentityFileAccess、FileInputs、FileViews、FilePurpose、UploadClaim、UploadCredentialFilter、BoundedDigestStream、UploadService、UploadCompletionService、MaterialRetentionPolicy、MaterialService、FileFormat、FileScanWorker、FileCleanupWorker、FileScheduling、FileController。

新增集成：integration/storage下ObjectStorage、S3ObjectStorage、StorageConfiguration、LegacyFileKeyConverter；integration/scanner下VirusScanner、ScanResult、ClamdScanner、ScannerConfiguration。新增sql/V9__files_and_jobs.sql。

共享小改：backend/pom.xml、SecurityConfiguration、application.yml、IdentityController的GET me、IdentityService构造与userResponse；删除UnavailableIdentityFiles。测试同步IdentityHttpTest构造参数、SessionHttpBoundaryTest精确Upload错误码、application-test.yml关闭调度。

新增测试：FileHttpTest、FileFormatTest、LiveFileIntegrationTest、ClamdScannerTest、StorageProtocolTest、LegacyFileKeyConverterTest及files-schema.sql。文档backend/README.md与docs/backend/files-and-materials.md。

排除主控文件：implementation-status.md、deployment-prerequisites.md、docs/superpowers/plans/2026-10-13-backend-server.md、ignored ledger/dev-dependencies。无force-add。

## RED/GREEN证据

所有命令工作目录C:/Users/19683/source/repos/caizhitong；JAVA_HOME=C:/Users/19683/AppData/Local/caizhitong-devtools/jdk-21.0.12.1+1；Maven完整路径C:/Users/19683/AppData/Local/caizhitong-devtools/apache-maven-3.9.16/bin/mvn.cmd。下文mvn代表该便携mvn.cmd，不使用其他runtime绕过审查。

| 轮次 | 命令/RED实际输出 | GREEN结果 |
| --- | --- | --- |
| 上传意向 | mvn -f backend/pom.xml -Dtest=FileHttpTest test；2026-10-14 18:30 Tests 1/Failures1，expected200 actual404 | 18:32同命令 exit0 |
| Upload链 | -Dtest=FileHttpTest#uploadCredentialAllowsBinaryOnceAndBearerCannotReplaceIt；旧denyAll返回403，expected401 | 独立链后4项仅未实现完成/材料404，上传两项通过 |
| 原子完成/材料 | FileHttpTest；Tests4 Failures2，expected202/201 actual404 | 完成与材料实现后4项通过；中间Timestamp类型修正后验证 |
| 扫描worker | FileHttpTest；expected fileScanWorker present true actualfalse | 原始扫描→图片clean→下载通过。曾定位测试PNG本身zlib校验坏，改用ImageIO生成真实夹具，未放松生产解析 |
| 清理worker | FileHttpTest；expected worker present true actualfalse | 到期孤儿清理与失败重试通过 |
| 严格请求 | FileHttpTest；C1 U+0085名称原expected400 actual200 | Character.isISOControl覆盖后通过 |
| DOCX目录 | FileHttpTest,FileFormatTest；2026-10-15 10:40 Tests13 Failures1，中央目录加密flag未拒绝 | 改中央目录读取后14项含ClamD协议通过 |
| 遗留转换 | LegacyFileKeyConverterTest；实现类缺失testCompile RED；先修复测试方法拼写再确认缺失原因 | 2项/0失败：专用权限拒绝、备份要求、加密读回/恢复、失败rollback |
| 历史保留 | FileHttpTest#materialCreatesAppendedImmutableVersionsAndProtectsRetention,StorageProtocolTest；10:48 growth证明引用时expected409 actual200 | 加现存growth保留检查后20项聚焦通过 |
| 自查宏/multipart | FileFormatTest#docxRejectsRenamedMacroPartAndCorruptCentralCrc,FileHttpTest#binaryUploadRejectsMultiplePartsMimeAndSizeMismatch；2项/2失败：重命名宏未拒绝、多file实际201 | 宏ContentType/关系及CRC检查、单file part后通过。请求受Spring安全包装，使用WebUtils解包，未放宽数量检查 |
| 旧安全探针 | 首次全套package Tests123 Failures1 Skipped1：原expect403，现返回401 | 精确断言401和INVALID_UPLOAD_CREDENTIAL，保留Bearer不能替代Upload负例 |

管理员撤销全部admin角色后，DatabaseActorLoader不再加载ADMIN Actor，Upload明确401（原新增测试误期望403，已按实际语义修正，拒绝仍存在）；保留其他有Actor但缺权限的403边界。

最后聚焦：mvn -f backend/pom.xml -Dtest=FileFormatTest,FileHttpTest,SessionHttpBoundaryTest test，2026-10-15 10:55 exit0：FileFormat5、FileHttp13、SessionHttp10，28项0失败0错误0跳过。

## 真实服务证据

2026-10-15 10:44执行LiveFileIntegrationTest：1项/0失败/0错误/0跳过，exit0。使用生产RedisSessionStore/RedisRateCounter、生产S3ObjectStorage与ClamdScanner，SQL是隔离H2而非真实MySQL。

已核对的本项目容器：czt-dev-redis 127.0.0.1:16379；czt-dev-garage S3 http://127.0.0.1:13900，私密bucket caizhitong-dev-private；czt-dev-clamav 127.0.0.1:13310。先核对label com.caizhitong.scope=development-integration，只捕获本次开发资源环境到进程变量，没有打印凭据、读旧凭据或修改容器。

执行形式（完整凭据值从不进入命令/报告）：PowerShell以docker inspect输出赋值并ConvertFrom-Json，从Config.Env提取CZT_REDIS_PASSWORD、GARAGE_DEFAULT_ACCESS_KEY、GARAGE_DEFAULT_SECRET_KEY，分别放到CZT_LIVE_REDIS_PASSWORD/CZT_LIVE_S3_ACCESS_KEY/CZT_LIVE_S3_SECRET_KEY；设置CZT_LIVE_FILES_TEST=true，再执行：

```powershell
& 'C:/Users/19683/AppData/Local/caizhitong-devtools/apache-maven-3.9.16/bin/mvn.cmd' -f backend/pom.xml '-Dtest=LiveFileIntegrationTest' test -q
```

finally移除四个测试环境变量。每个命令进程仅临时追加Docker Desktop resources/bin到PATH，不改系统PATH/credstore。

实际路径：真实Redis会话→意向→Upload→S3隔离对象→原始ClamD扫描→图片重编码clean→S3签名HTTP200且图片可解码→去签名匿名HTTP403→清理旧隔离对象；另通过相同真实扫描适配器，正常PNG=CLEAN、EICAR=INFECTED。测试finally清理自己生成的对象和会话，不清空bucket/Redis。

## 遗留转换与回滚

V9保留旧object_key。工具必须显式--backup-confirmed、具体表及行ID，并使用专用czt_file_key_operator，核对CURRENT_USER/显式列级UPDATE/转换日志权限。逐条短事务内写密文、回读解密核对、记file_key_migrations，最后清明文；失败回滚原状态。restore要求同备份编号、日志与当前密文一致。业务账号不获得material_versions UPDATE。

操作前冻结相关历史写入、备份/恢复演练；操作步骤与必需环境变量见docs/backend/files-and-materials.md。恢复后再次转换需要人工审查/归档记录，不能覆盖审计。真实旧数据库转换尚未执行；内存工具测试不是实际迁移完成证明。该工具不补校园/新附件关联/扫描，旧记录不能因此作为新clean附件使用。

## 尚未验收与范围限制

- 真实MySQL V9 DDL/复合外键/业务最小权限，以及专用转换账号information_schema授权检查，留部署验收；未访问既有MySQL84。
- 真实旧数据转换、真实迁移恢复演练未执行。未将旧字段静默清空。
- 后续机会/通知/资源/消息等模块必须明确接入LinkedAttachmentPolicy与保留策略，当前没有任意校内文件共享，也没有清单/预检功能。
- 真实文件链路不等于生产容量、长时间故障、并发进程崩溃及病毒库运营验收。容器配置/病毒库健康证据由主控维护；本次只声明上述实际业务路径。
- 全套中原身份并发/WARN与10MiB名单性能增强仍按主控计划留Task14；未据此扩大重构。

## 最终验证与本地检查点

最终全套（未设置CZT_LIVE_FILES_TEST）：

```text
mvn -f backend/pom.xml package
Tests run: 125, Failures: 0, Errors: 0, Skipped: 1
BUILD SUCCESS
Total time: 23.534 s
Finished at: 2026-10-15T10:56:38+08:00
```

125项中124项默认运行通过，唯一skip是显式环境条件的LiveFileIntegrationTest，不将该skip作为真实联调完成证明。随后在相同最终源码上独立设置真实服务测试环境，执行上文相同凭据捕获方式及`mvn -f backend/pom.xml -Dtest=LiveFileIntegrationTest test`（本次不带-q）：

```text
Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
Total time: 11.836 s
Finished at: 2026-10-15T10:58:41+08:00
```

最终测试明细在backend/target/surefire-reports；LiveFileIntegrationTest.txt现为1/0/0/0，真实运行没有环境条件skip。已检查生产JAR包含V1–V9，未包含H2、identity-schema/files-schema或application-test资源。git diff --check通过；V1–V8 diff为空。

本地checkpoint：8d7284697ff610992a475b88e83b43b82e413bb3，`feat(files): add secure uploads and material foundation`。只提交47个Task4源/测试/配置/文件说明文件，1617插入/21删除。提交后工作树仅剩主控的deployment-prerequisites、implementation-status和主计划三份未提交修改；本报告由git check-ignore确认ignored，未force-add、未push。
