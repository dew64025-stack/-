# Task 1 implementation report

Status: DONE_WITH_CONCERNS (deployment verification remains outside Task 1; no implementation blocker).

Base: `688923ec1d1e6ba00bdcdfe5ac3de39b66125351`.
Local checkpoint: `78a21d15f691bd4464e8fb537d16d58110795ba3` — `feat(backend): establish secure server foundation`.
Branch: `feature/backend-server`. No push, merge, or PR creation performed.

## Requirements and resulting behavior

- Maven Java 21, Spring Boot 4.1.1; MVC, Security, Validation, JPA, Redis, Flyway/MySQL, Actuator. H2 and test starters are test scope only. No Lombok or unrelated dependency.
- `ApiResponse<T>` exposes success/data/error/requestId/timestamp; only null data/error are omitted. `ApiError` always has fieldErrors array and retryable. No global Long serialization rule; DTO callers explicitly provide string IDs, while ordinary counts remain JSON numbers.
- `BusinessException(int status, String code, String message, List<ApiFieldError>, boolean retryable)` exposes getStatus/getCode/getMessage/getFieldErrors/isRetryable; three-argument int/HttpStatus overloads also available. Its messages must be safe business text supplied by callers.
- Global advice covers body Bean Validation, unreadable/unknown JSON, argument type mismatch, method validation, missing parameters, 409 optimistic locking, 403, 401, 404 static-resource misses, and safe generic 500. Internal messages/causes are never copied to the envelope or logged.
- `RequestIdFilter` creates `req_` plus random UUID, uses a private servlet attribute, sets X-Request-Id, and ignores the inbound header. Filters and controller errors share the same request ID.
- `JsonSecurityErrors` supplies JSON for authentication, access and CSRF denials. All routes remain denied, no public permitAll, fake authentication, default user/password, or login page. Session policy is stateless; CSRF protection remains enabled for Task 1. Task 2 must replace security rules deliberately.
- Jackson 3 JSON mapper rejects unknown DTO fields. Controllers must return explicit DTOs rather than entities; no business DTO/entity is added in this task.
- `SensitiveDataCrypto`: AES-256-GCM, random 12-byte nonce, purpose as AAD, envelope version=1 + nonce + encrypted bytes including 16-byte tag. Malformed version, tamper, wrong purpose/key all reject safely. Distinct AES and HMAC keys are required; constructor copies key material. Encryption returns byte[], decrypt returns String, searchHash returns 32-byte HMAC-SHA256 bytes. HMAC input is four-byte purpose UTF-8 length + purpose UTF-8 bytes + text UTF-8 bytes, avoiding purpose/text concatenation ambiguity.
- `SnowflakeIds(Clock, int).nextId()` is synchronized, uses 2026-01-01T00:00:00Z epoch, 41/10/12 bit layout, validates worker 0..1023 and timestamp bounds, rejects rollback. On 4096 IDs in one millisecond it waits for advancement with a 100ms upper bound, rejects a stopped clock or interrupted wait, and never reuses sequence values.
- Configuration requires deployment-provided Base64 AES/HMAC keys and worker ID, with no production random fallback. MySQL and Redis credentials use environment placeholders. MySQL connections and Hibernate use UTC, ddl-auto=validate, open-in-view=false, show-sql=false.
- Flyway has independent migration credentials, clean-disabled=true, baseline-on-migrate=false. A static BeanFactoryPostProcessor rejects a non-MySQL datasource or equal app/Flyway users before initialization side effects. The test profile bypasses only this production check and uses test-only H2, fixed test keys, and disabled Flyway.
- Maven resource mapping copies existing root sql/V1..V6 byte-for-byte into classpath:db/migration. No SQL, schema, demo seed, database account, or actual database was modified.
- Existing `.gitignore` already excludes targets, logs, secrets and `.superpowers`; it was not changed. Main's modified plan and untracked route inventory were not staged.

## RED / GREEN evidence

All Maven commands ran from `C:/Users/19683/source/repos/caizhitong` with:

```powershell
$env:JAVA_HOME='C:/Users/19683/AppData/Local/caizhitong-devtools/jdk-21.0.12.1+1'
$env:MAVEN_OPTS='-Duser.language=en -Duser.country=US'
```

Maven executable: `C:/Users/19683/AppData/Local/caizhitong-devtools/apache-maven-3.9.16/bin/mvn.cmd`.

1. Initial RED, before production source: `mvn -B -ntp -f backend/pom.xml test` exited 1 with 32 missing-symbol compilation errors for requested unimplemented classes. Exact readable output: `task-1-red-compile.txt`.
2. Behavior RED: safe fail-closed skeletal Crypto/ID constructors, then `mvn -B -ntp -f backend/pom.xml '-Dtest=CryptoTest,SnowflakeIdsTest' test`; 10 tests, 2 failures, 8 errors, exit 1. Failures were expected validation types and unavailable encryption/ID behavior, not dependency/network failures. Reports saved in `task-1-red-behavior.txt`. All skeletal code was subsequently replaced; no placeholder was committed.
3. First implementation run: Crypto 5/5, API boundary 4/4, configuration 2/2 green; security 3 failures (anonymous 403 instead of 401 and empty response JSON), Snowflake concurrency 1 error at sequence exhaustion. Saved real failures in `task-1-red-security.txt`.
4. Focused GREEN: `mvn -B -ntp -f backend/pom.xml '-Dtest=SnowflakeIdsTest,SecurityBoundaryTest' test`; 8 tests, 0 failures/errors, exit 0 after bounded ID wait and JSON Security handlers.
5. First full package passed 19 tests, exit 0. Self-review then found database guard ordering could allow an earlier migration bean to initialize first; this justified an additional focused test and final package rather than relying on stale evidence.
6. Additional RED: `mvn -B -ntp -f backend/pom.xml '-Dtest=ConfigurationTest' test`; 3 tests, 1 failure: migration initialization side effect occurred before shared-account rejection. Saved `task-1-red-database-order.txt`.
7. Database ordering GREEN after moving guard to static BeanFactoryPostProcessor: same focused command, 3 tests, 0 failures/errors, exit 0. The test deliberately constructs a bad configuration and logs one safe expected startup-rejection WARN.
8. Final full suite + executable JAR: `mvn -B -ntp -f backend/pom.xml package`; 20 tests, 0 failures, 0 errors, 0 skipped; BUILD SUCCESS, exit 0, 2026-10-13T19:58:16+08:00. Full captured output: `task-1-green-package.txt`. Mockito is configured as a startup test agent, avoiding Java 21 dynamic attachment warnings without changing production.

The final suite comprises CryptoTest (5), SnowflakeIdsTest (5), ApiBoundaryTest (4), ConfigurationTest (3), SecurityBoundaryTest (3). Tests exercise real crypto, clock/concurrency, mapper, MVC advice, security chain, and configuration initialization; no source-text assertions or mocks are used. Synthetic authenticated users are test-only Spring Security fixtures.

## Artifact checks

Opened `backend/target/backend-0.0.1-SNAPSHOT.jar` read-only with .NET ZipFile; SHA-256 compared each BOOT-INF/classes/db/migration/V1..V6 entry stream with the corresponding root SQL file. All six were byte-for-byte identical. Confirmed absent: BOOT-INF/lib/h2-*, application-test.yml, demo_seed.sql. `git diff --name-only -- sql` returned no output. `git diff --cached --check` passed before commit. Source scan found no TODO, unavailable placeholder, printStackTrace, System.out, permitAll or embedded password assignment.

## Changed files (22)

- backend/pom.xml
- backend/README.md
- backend/src/main/java/com/caizhitong/CaizhitongApplication.java
- backend/src/main/java/com/caizhitong/common/ApiError.java
- backend/src/main/java/com/caizhitong/common/ApiFieldError.java
- backend/src/main/java/com/caizhitong/common/ApiResponse.java
- backend/src/main/java/com/caizhitong/common/BusinessException.java
- backend/src/main/java/com/caizhitong/common/GlobalExceptionHandler.java
- backend/src/main/java/com/caizhitong/common/JsonSecurityErrors.java
- backend/src/main/java/com/caizhitong/common/RequestIdFilter.java
- backend/src/main/java/com/caizhitong/common/SensitiveDataCrypto.java
- backend/src/main/java/com/caizhitong/common/SnowflakeIds.java
- backend/src/main/java/com/caizhitong/config/CoreConfiguration.java
- backend/src/main/java/com/caizhitong/config/JsonConfiguration.java
- backend/src/main/java/com/caizhitong/config/SecurityConfiguration.java
- backend/src/main/resources/application.yml
- backend/src/test/java/com/caizhitong/common/ApiBoundaryTest.java
- backend/src/test/java/com/caizhitong/common/ConfigurationTest.java
- backend/src/test/java/com/caizhitong/common/CryptoTest.java
- backend/src/test/java/com/caizhitong/common/SecurityBoundaryTest.java
- backend/src/test/java/com/caizhitong/common/SnowflakeIdsTest.java
- backend/src/test/resources/application-test.yml

## Self-review, decisions, concerns

- Reviewed scope against Task 1: no business/session/auth implementation, schema mutation, external submission, secret fallback, entity response, or broad refactor.
- Ruling: use distinct test key arrays instead of the brief's zero-key example — preserves actual key independence; cost if wrong is adjusting fixtures or constructor policy, not production data.
- Ruling: wait up to 100ms after ID sequence exhaustion — first concurrent test proved immediate rejection was too strict; cost if wrong is bounded additional latency at more than 4096 IDs/ms/worker. Frozen clocks still reject instead of hanging.
- Ruling: validate production database settings during bean-factory post-processing — regression test proved ordinary bean initialization was too late; cost if wrong is rejecting unusual deployment configs earlier, before migrations.
- Automatic approval review rejected an intermediate patch containing plaintext/constant-ID test placeholders because those could persist unsafe code. That patch was not applied. A safer fail-closed skeleton was approved, exercised, and fully replaced. No action remains blocked and no approval request is needed.
- H2 startup is test-only evidence. No live MySQL migration, Redis connection, MySQL privilege verification, real production startup, or published endpoint was claimed. Those remain later environment/integration acceptance tasks.
- Worker IDs must be deployment-unique, and restarting one worker requires clock advancement beyond prior emitted IDs. AES/HMAC rotation needs a separate controlled data migration; version 1 encodes format, not a key registry.
- BusinessException callers must supply public messages/field errors; generic advice intentionally suppresses all internal exception messages. Later code should not wrap SQL/errors as business text.
- Parent/controller owns task review and final branch integration. No reviewer or subagent was dispatched by this implementer.
