$ErrorActionPreference = 'Stop'
$dockerCli = 'C:\Users\19683\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe'
$env:PATH = (Split-Path -Parent $dockerCli) + ';' + $env:PATH
$existingContainer = & $dockerCli container ls --all --filter 'name=^/czt-dev-mysql-test$' --format '{{.Names}}'
if ($LASTEXITCODE -ne 0 -or $existingContainer) { throw 'Test container already exists; inspect and reuse explicitly instead' }
$existingVolume = & $dockerCli volume ls --filter 'name=czt-backend-mysql-test_mysql-test-data' --format '{{.Name}}'
if ($LASTEXITCODE -ne 0 -or $existingVolume) { throw 'Test volume already exists; do not overwrite or reset it' }
if (@(Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 13306).Count -gt 0) { throw 'Test port 13306 is already in use' }
$imageDigest = 'mysql@sha256:24989179f58856db763f418010c1169fecc944e3ec1ea7e921572d83eb070f70'
$knownDigests = & $dockerCli image inspect mysql:8.4.11 --format '{{json .RepoDigests}}'
if ($LASTEXITCODE -ne 0 -or $imageDigest -notin ($knownDigests | ConvertFrom-Json)) { throw 'Test image digest mismatch' }
$random = [System.Security.Cryptography.RandomNumberGenerator]::Create()
try {
    $rootSecret = New-Object byte[] 32
    $testSecret = New-Object byte[] 32
    $random.GetBytes($rootSecret)
    $random.GetBytes($testSecret)
    $env:CZT_MYSQL_TEST_ROOT_PASSWORD = [Convert]::ToHexString($rootSecret)
    $env:CZT_MYSQL_TEST_PASSWORD = [Convert]::ToHexString($testSecret)
    $env:CZT_MYSQL_TEST_IMAGE = $imageDigest
    $composePath = Join-Path $PSScriptRoot 'mysql.compose.yml'
    & $dockerCli compose --file $composePath config --quiet
    if ($LASTEXITCODE -ne 0) { throw 'Test compose validation failed' }
    & $dockerCli compose --file $composePath up --detach
    if ($LASTEXITCODE -ne 0) { throw 'Test MySQL could not start' }
    Write-Output 'Isolated MySQL test container created; health/readiness still requires verification'
} finally {
    $random.Dispose()
    Remove-Item Env:CZT_MYSQL_TEST_ROOT_PASSWORD,Env:CZT_MYSQL_TEST_PASSWORD,Env:CZT_MYSQL_TEST_IMAGE -ErrorAction SilentlyContinue
}
