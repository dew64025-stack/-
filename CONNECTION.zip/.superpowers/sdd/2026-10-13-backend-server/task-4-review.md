# Task4 independent review at 8d7284697ff610992a475b88e83b43b82e413bb3

Reviewer: /root/backend_files_review, gpt-6-astra high. Spec Issues found; Task quality Needs fixes. Critical0/Important3/Minor0. Readonly full diff2199lines; focused existingtransaction/driver checks, no tests rerun.

## Findings under verification (verbatim)

1. **真实 MySQL 上首次完成上传会因时间类型强转失败。**
   [UploadCompletionService.java:29](C:/Users/19683/source/repos/caizhitong/backend/src/main/java/com/caizhitong/material/files/UploadCompletionService.java:29) 将 `queryForMap()` 返回的 `expires_at` 强转为 `java.sql.Timestamp`。V9 定义该列为 `DATETIME(3)`；实际依赖 Connector/J 9.7.0 默认 `treatMysqlDatetimeAsTimestamp=false`，返回 `LocalDateTime`，Spring 的无目标类型取值也不转换它。有效上传进入 `/files/uploads/{id}/complete` 或管理员对应入口，即抛出 `ClassCastException`，附件和扫描任务无法创建。H2 返回 Timestamp，因此现有测试无法发现。应使用明确类型的 RowMapper，例如 `getObject("expires_at", LocalDateTime.class)`，并增加覆盖 MySQL 返回类型的回归验证。

2. **共享附件的删除检查在 MySQL REPEATABLE READ 下可能漏掉刚提交的引用，删除仍被使用的对象。**
   [MaterialService.java:64](C:/Users/19683/source/repos/caizhitong/backend/src/main/java/com/caizhitong/material/files/MaterialService.java:64) 虽然在获取附件锁后检查其他材料，但检查使用普通 `SELECT COUNT(*)`，仍属于快照读取。交错条件：删除事务 D 在第 34 行 `authorize()` 的普通查询建立快照；创建事务 C 随后锁定同一附件，创建材料 B 和版本并提交；D 再取得附件锁，但第 64 行仍读取旧快照，看不到 B，于是第 65–66 行将附件置 deleted 并安排物理清理。B 的不可变版本随即指向不可下载、最终被删除的内容。定向检查确认 `IdempotencyExecutor` 未指定隔离级别，应用配置也未覆盖，因此部署使用 MySQL 默认 REPEATABLE READ 时存在此路径。应让引用检查读取最新已提交状态，并统一引用增加/删除的锁协议；补充带明确交错控制的 MySQL 并发回归。

3. **慢上传可在清理任务完成后写入对象，留下永远不会再清理的孤儿。**
   [UploadService.java:54](C:/Users/19683/source/repos/caizhitong/backend/src/main/java/com/caizhitong/material/files/UploadService.java:54)、[FileCleanupWorker.java:33](C:/Users/19683/source/repos/caizhitong/backend/src/main/java/com/caizhitong/material/files/FileCleanupWorker.java:33)：领取凭据后立即安排十分钟后的清理，但清理只检查 active 附件，没有协调仍在进行的上传。具体路径：请求领取凭据后，在懒解析 multipart 阶段持续缓慢上传超过十分钟；清理 worker 删除尚不存在的对象并将任务置 succeeded；请求随后进入第 63–66 行，仍可写入对象并将上传改为 uploaded。此时 complete 因凭据期限已过而拒绝，已经 succeeded 的清理任务也不再重试，造成永久孤儿。S3 请求超时不能限制此前的客户端 multipart 接收时长。应协调上传终止与清理状态，并保证迟到的对象写入重新登记可靠清理；用可控阻塞上传和时钟推进覆盖该交错。

## Cannot verify

- V9真实MySQL迁移、复合外键及业务最小权限。
- LegacyFileKeyConverter真实专用权限、旧数据转换/恢复；当前权限测试有替身。
- 后续关联业务授权及AI/历史保留策略实际接入。

## Controller verification and disposition

Main confirmed exactTimestamp cast/V9DATETIME/driver9.7.0/defaultURL with no override. Oracleprimary documentation https://dev.mysql.com/doc/connector-j/en/connector-j-connp-props-datetime-types-processing.html explicitly defaultfalse since8.2.0 and getObject DATETIME→LocalDateTime. No globaldriverflag workaround planned. Original125 tests green doesnot cover these productiondifferences. MySQL native independenttestcontainer preparation started, existingMySQL84/3306 untouched. Allthree findings assigned round1 to originalimplementer; task remainsblockedbyreview, notcomplete.
