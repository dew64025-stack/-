$ErrorActionPreference = 'Stop'
$checkoutPath = 'C:\Users\19683\source\repos\caizhitong'
if ((Get-Location).Path -ne $checkoutPath) { throw 'Run verification from the expected checkout' }
$dockerCli = 'C:\Users\19683\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe'
$env:PATH = (Split-Path -Parent $dockerCli) + ';' + $env:PATH
foreach ($containerName in @('czt-dev-redis', 'czt-dev-garage', 'czt-dev-clamav', 'czt-dev-mysql-test')) {
    $resourceScope = & $dockerCli inspect $containerName --format '{{index .Config.Labels "com.caizhitong.scope"}}'
    if ($LASTEXITCODE -ne 0 -or $resourceScope -ne 'development-integration') { throw 'Unexpected development resource scope' }
    $healthState = & $dockerCli inspect $containerName --format '{{.State.Health.Status}}'
    if ($LASTEXITCODE -ne 0 -or $healthState -ne 'healthy') { throw 'Development resource is not healthy' }
}
$databasePurpose = & $dockerCli inspect czt-dev-mysql-test --format '{{index .Config.Labels "com.caizhitong.purpose"}}'
if ($LASTEXITCODE -ne 0 -or $databasePurpose -ne 'isolated-mysql-test') { throw 'Unexpected database test resource purpose' }
function Get-ScopedDevelopmentEnvironment([string]$containerName) {
    $rawEnvironment = & $dockerCli inspect $containerName --format '{{json .Config.Env}}'
    if ($LASTEXITCODE -ne 0) { throw 'Cannot read scoped development configuration' }
    $result = @{}
    foreach ($entry in ($rawEnvironment | ConvertFrom-Json)) {
        $parts = $entry -split '=', 2
        if ($parts.Length -eq 2) { $result[$parts[0]] = $parts[1] }
    }
    return $result
}
$redisConfiguration = Get-ScopedDevelopmentEnvironment 'czt-dev-redis'
$storageConfiguration = Get-ScopedDevelopmentEnvironment 'czt-dev-garage'
$mysqlConfiguration = Get-ScopedDevelopmentEnvironment 'czt-dev-mysql-test'
$env:CZT_LIVE_FILES_TEST = 'true'
$env:CZT_MYSQL_FILES_TEST = 'true'
$env:CZT_MYSQL_TEST_PASSWORD = $mysqlConfiguration['MYSQL_PASSWORD']
$env:CZT_LIVE_REDIS_PASSWORD = $redisConfiguration['CZT_REDIS_PASSWORD']
$env:CZT_LIVE_S3_ACCESS_KEY = $storageConfiguration['GARAGE_DEFAULT_ACCESS_KEY']
$env:CZT_LIVE_S3_SECRET_KEY = $storageConfiguration['GARAGE_DEFAULT_SECRET_KEY']
foreach ($value in @($env:CZT_LIVE_REDIS_PASSWORD, $env:CZT_LIVE_S3_ACCESS_KEY, $env:CZT_LIVE_S3_SECRET_KEY, $env:CZT_MYSQL_TEST_PASSWORD)) {
    if ([string]::IsNullOrWhiteSpace($value)) { throw 'Scoped development test configuration missing' }
}
$env:JAVA_HOME = 'C:\Users\19683\AppData\Local\caizhitong-devtools\jdk-21.0.12.1+1'
$env:MAVEN_OPTS = '-Duser.language=en -Duser.country=US'
& 'C:\Users\19683\AppData\Local\caizhitong-devtools\apache-maven-3.9.16\bin\mvn.cmd' -B -ntp -f backend/pom.xml package
if ($LASTEXITCODE -ne 0) { throw 'Maven package failed' }
$totals = @{ tests = 0; failures = 0; errors = 0; skipped = 0 }
Get-ChildItem -LiteralPath 'backend\target\surefire-reports' -Filter 'TEST-*.xml' | ForEach-Object {
    [xml]$suite = Get-Content -LiteralPath $_.FullName -Raw
    foreach ($metric in @('tests', 'failures', 'errors', 'skipped')) { $totals[$metric] += [int]$suite.testsuite.$metric }
}
if ($totals.failures -ne 0 -or $totals.errors -ne 0 -or $totals.skipped -ne 0) { throw 'Tests did not all execute successfully' }
Write-Output ('Fresh test totals: ' + ($totals | ConvertTo-Json -Compress))
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead((Join-Path $checkoutPath 'backend\target\backend-0.0.1-SNAPSHOT.jar'))
try {
    $rejectedEntries = @($archive.Entries | Where-Object { $_.FullName -match '(^|/)(application-test\.yml|identity-schema\.sql|files-schema\.sql|\.env)(/|$)|BOOT-INF/lib/h2-|BOOT-INF/classes/.*Test\.class$|db/demo/' })
    if ($rejectedEntries.Count -gt 0) { throw 'Unexpected test or private resource packaged' }
    $migrationCount = 0
    foreach ($migration in (Get-ChildItem -LiteralPath 'sql' -Filter 'V*__*.sql')) {
        $entry = $archive.GetEntry('BOOT-INF/classes/db/migration/' + $migration.Name)
        if ($null -eq $entry) { throw 'Migration missing from JAR' }
        $input = $entry.Open()
        try {
            $hasher = [System.Security.Cryptography.SHA256]::Create()
            try { $packedHash = [System.Convert]::ToHexString($hasher.ComputeHash($input)) } finally { $hasher.Dispose() }
        } finally { $input.Dispose() }
        if ($packedHash -ne (Get-FileHash -LiteralPath $migration.FullName -Algorithm SHA256).Hash) { throw 'Migration hash differs in JAR' }
        $migrationCount++
    }
    Write-Output "JAR: $migrationCount migration hashes match; no test/private resources detected"
} finally { $archive.Dispose() }
Write-Output ('Verified at ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'))
