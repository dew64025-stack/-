## Task 3: 微信身份、手机号、学生认证与名单

**Files:** identity/、campus/、integration/wechat/、admin/identity/；sql/V8__identity_runtime.sql；test相同域。
**Interfaces:** 微信Jscode2session只服务器交换；手机号一次性code换取真实号码；AppID从环境配置。个人基础资料与画像分别用version。名单保存HMAC学号与密文字段。用户现已确认：学校身份接口先预留，当前保留人工复核；名单命中也不自动授予学生权限。拒绝后允许重新申请，不允许占用他人已验证学号。学校接口未提供协议/可信凭据时不能伪造verified结果。

**精确路由范围：** API第4节的13个接口（含微信登录），第16.1节6个管理员身份接口，以及第16.2节认证列表/decision、名单imports、users列表和roles赋予/撤销。第16.2节文件接口由Task4接入，校园创建/配置/统计由Task13实现。增加必要的GET /admin/auth/csrf来获取CSRF凭证，属于安全辅助路由，不替代206个计划接口。公开GET校园组织/地区从登录校园或开放campusCode选取，不允许登录用户切换校园。

**输入与资料：** 独立DTO拒绝未知属性和标量转换，version只能非负JSON整数；ID/学号/code只能JSON字符串；字符串数组不能接收数字、对象、null。至少修改一个可编辑字段，显式null仅对允许清除的字段生效。college来自本校active college组织，grade来自本校配置profile.allowedGrades；没有允许值时拒绝设置，不猜测任何年份均合法。老用户无画像时返回空数组和version=0，首次更新锁定users行、创建version=1，后续使用user_profiles.version；并发首次更新最多一次成功。不修改users.version来替代画像version。

**微信边界：** 微信登录与手机号换码远程请求在业务事务外；固定https://api.weixin.qq.com，禁止用户提供上游地址/重定向。连接超时2秒、请求超时8秒，响应限制256KiB，错误不输出请求URL、AppSecret、token、code、openid或手机号。登录code按摘要短时去重并限流，重复code不能因上游替身返回相同结果而创建第二账号。同app_id/openid唯一约束与重试读处理同时登录竞争；服务器既有校园不能被campusCode更改。手机号只接受微信返回值，校验watermark.appid，按countryCode和号码规范化检索；事务锁用户并保持一个当前已验证号码、记录新的phone授权，不把历史撤回当作有效授权。数据库唯一冲突返回安全业务错误，不泄露他人归属。

有效学生refresh可在access过期时登出，学生/管理员refresh入口由各自真实刷新凭据验证；附带过期access Header不能抢先阻断这些精确凭据路由。没有有效刷新凭据仍401；不能全局忽略非法Bearer，普通业务以及admin logout/reauth仍保持所需身份/CSRF检查。

微信标识按服务器返回的不透明字符串原样精确匹配，不能lowercase或依赖unionid自动合并。V1的utf8mb4_unicode_ci会忽略大小写，V8对app_id/openid保留utf8mb4字符集与列长度/约束，仅改为utf8mb4_0900_bin（NO PAD）的binary语义；仅大小写不同的openid不能混号，不做有损字符转换/静默清数据。H2默认字符串比较不能替代真实MySQL collation验证，须记录测试范围。依据：https://dev.mysql.com/doc/refman/8.0/en/charset-mysql.html 。

**人工认证与V8：** 删除旧的全状态uq_student_campus_search，改为同校一个verified学号归属，以及每用户至多一个pending/verified申请的可空生成列唯一索引；保留检索索引和被拒绝的历史。创建约束遇到旧冲突必须失败，不能自动删数据。申请最长32、加密且HMAC；同学号的待审申请不永久占号，名单匹配只能附带审核线索。approve/reject校验本校identity.review、pending状态、当前version和手机号当前有效；rejectReason最长255、普通reason最长512。决定和不可变审计同事务；未认证不赋予学生业务能力。学校提供器只声明未来可信接入能力和明确未配置状态，不暴露猜测的认证callback。

**管理员：** V8补独立管理员凭据和加密MFA种子、TOTP防重放状态及名单表，初始化只能受控CLI且显式操作员参数/环境输入，无默认账号/密码，无公开注册，不输出密码/种子到日志。密码BCrypt且登录限流，失败信息统一。先密码挑战，再6位TOTP（30秒步长、±1窗口），挑战摘要存Redis且一次消费，TOTP时间步数据库条件更新防重放；任何失败不签发admin会话。管理员JSON的refreshToken为null，通过Secure/HttpOnly/SameSite=Strict刷新Cookie交付。GET /admin/auth/csrf公开但仅返回当前请求的CSRF凭证和安全Cookie；登录/MFA/刷新也必须CSRF，logout/reauth必须有效active管理员。reauthToken随机、存摘要、有效5分钟、绑定当前admin与校园，敏感动作一次性消费。角色赋权要求user.roles和reauth；不能授予操作者没有的权限/外校权限，不能凭campus_admin授予security_investigator/platform_admin；角色撤销即时影响Task2 ActorLoader。返回脱敏队列/用户列表，敏感字段不进入审计detail。

**文件依赖交接：** 头像与名单输入依赖Task4的已扫描私密文件。Task3声明窄接口验证附件归属/用途/scanStatus并读取受限字节；未接入时明确拒绝，不返回假的URL/导入成功。Task4必须替换为真实实现并补跨域测试。名单CSV限制10MiB、UTF-8、studentNumber/college/grade/status四列，排除格式/重复/非法值后持久化HMAC和密文字段；任务登记与审计同事务，扫描/读取不持有长数据库事务。是否命中名单不能自动认证。Task3审查须列出文件依赖尚未联通，最终验收不得把它算已完成。

名单status精确为active/inactive，只有active是辅助审核命中；inactive不自动撤销认证，任何名单状态都不自动授予权限。POST /admin/student-roster/imports必须真正异步：HTTP202先登记pending任务与审计，后台限量领取后在数据库事务外读取/解析clean附件，再原子持久化有效行与摘要结果/任务succeeded状态。失败可有限重试并回收失效领取，不能同步处理完后仍冒充202异步受理。必要的async_jobs.campus_id/owner_user_id/access_domain元信息可提前由V8补充，Task4复用、不重复加列；旧未知归属保持NULL且不可凭猜测开放给用户。报告错误摘要只含行号/错误码，不含明文学号、CSV行或秘密；测试手动驱动真实worker，关闭自动定时只限测试配置。

**已有测试兼容：** 新Controller会使旧SessionHttpBoundaryTest中的未实现路由从404变为真实响应；同步调整受影响的探针/切片或真实数据夹具，保留原安全断言，不通过排除真实安全链/删除失败用例来绿灯。测试数据库按套件隔离，不能依赖另一套件恰好先建表或写入数据。

- [ ] RED：API第4节全部身份/校园接口，测试未知字段、跨校登录、更换campusCode、重复微信身份、手机号归属冲突、未绑定手机认证拒绝、名单不匹配pending、拒绝后重申请、画像版本409。
- [ ] RED：JSON类型严格边界：数字ID不能当String接收，boolean不能从字符串true转换，skills/interests元素必须字符串；日期、金额、枚举不能依赖隐式类型转换。失败返回400，不触发外部调用或数据库写入。
- [ ] RED：管理员密码失败不发会话，挑战重放、TOTP重放、角色撤销、跨校复核/越级赋权拒绝；安全Cookie与CSRF真实请求验证、reauth超时/错误归属；认证审批与审计/幂等同事务。
- [ ] 微信HTTP适配设置超时、可信固定域名，微信失败不创建虚假身份；测试用本地HTTP替身，不对生产提供fake开关。学校认证定义提供器接口与未接入状态，不开放猜测协议的公网回调。
- [ ] 追加名单和运行时模型/最小权限授权；管理员认证/名单导入和复核记录审计。
- [ ] GREEN：完整身份闭环及隔离测试，本地检查点。

