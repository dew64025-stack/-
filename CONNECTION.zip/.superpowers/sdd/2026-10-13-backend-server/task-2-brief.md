## Task 2: Redis会话、权限、幂等与限流

**Files:** backend/src/main/java/com/caizhitong/security/；backend/src/main/java/com/caizhitong/common/idempotency/；backend/src/main/java/com/caizhitong/common/pagination/；backend/src/main/java/com/caizhitong/common/ratelimit/；sql/V7__runtime_coordination.sql；backend/src/test/java/com/caizhitong/security/及common对应子包。
**Consumes:** Task1 ApiResponse/BusinessException/SnowflakeIds/SensitiveDataCrypto，生产DataSource/Redis与Clock。
**Produces:**
- Actor(long userId,long campusId,Set<String> permissions,boolean phoneBound,boolean studentVerified,String status,SessionKind kind)，kind=STUDENT/ADMIN。
- CurrentActor.require()、optional()、requireAuthenticatedIdentity()、requireStudent()、requirePermission(String)。require默认拒绝非active；requireAuthenticatedIdentity仅证明会话身份，供明确受限账号数据权利端点使用；requireStudent同时要求手机号已验证和认证verified。已删除账号/已撤销会话始终拒绝。
- ActorLoader.load(long userId,long campusId,SessionKind kind): Optional<Actor>。实现通过JPA EntityManager参数化native读取现有users/phones/verifications/roles；phoneBound必须同时有已验证号码和当前有效phone授权，撤回授权后不能只凭历史verified号码继续放行。管理员namespace只有合法管理员角色，业务处理身份动态重查，不接受Redis缓存的客户端权限。
- SessionTokens(accessToken,expiresIn,refreshToken,refreshExpiresIn)；SessionTokenService.issue(long userId,long campusId,SessionKind)、authenticate(String,SessionKind)、refresh(String,SessionKind)、revoke(String,SessionKind)。JWT不是本项目方案，token使用SecureRandom 32字节base64url。
- CursorCodec.encode(CursorPayload)、decode(String token,String scope)：payload含排序键和scope，签名HMAC，客户端不能跨校园/过滤条件复用。
- @BusinessWrite应用服务注解与IdempotencyContext；IdempotencyExecutor在一个MySQL事务内执行真实业务及幂等结果持久化，Controller业务命令不得直接绕过此服务边界。
- RateLimiter.check(String bucket,int max,Duration window)，原子Redis计数，超限429，Redis失效503。

**事务与失败规则：** 幂等范围含namespace、user、campus、method、真实路由及key摘要。过滤器只验证业务写头并绑定规范化请求摘要，不在过滤器结束后另存已经提交的业务结果。应用服务@BusinessWrite在事务里先占唯一记录、执行业务、保存加密DTO结果后一起提交；异常一起回滚。重复提交返回相同业务data，但外层requestId是当前请求的新ID。同键不同摘要409；竞争中已提交的结果可读，未完成或锁超时409/503可重试；不能catch后强行提交回滚事务。权限检查在幂等重放之前（服务@PreAuthorize或Controller明确检查），不能因重放绕过当前撤权。注解只用于实际业务写入，不包远程微信换码/AI模型/文件扫描调用。

**会话规则：** Redis只存token摘要和userId/campusId/kind/sessionId，access900秒、refresh604800秒。refresh Lua一次性消费并轮换整个会话，撤旧access和refresh，两个并发刷新只成功一次。namespace不可互换。access认证每次加载当前数据库状态，找不到/已删用户拒绝；受限用户仍保留可验证身份，但只能访问严格白名单的本人处罚/申诉/数据权利，不能恢复发布等业务权限。权限配置由roles.code静态矩阵映射，不接受请求roles。撤销同会话token。JSON和日志禁止原始token。Redis不可用不放行。未知/过期token401。

**HTTP边界：** 只解析Bearer认证，客户端userId/campusId/roles字段不产生身份。学生端stateless bearer请求独立安全链；admin链隔离，学生token不通过。admin cookie写操作CSRF不能关闭，cookie Secure/HttpOnly/SameSite，具体管理员登录和MFA在Task3接入。公开GET仅允许文档P/P-L的特定路径，未实现路由仍404，不能通配允许所有写。临时Upload二进制凭据由Task4独立验证，不用Bearer当上传凭据。默认生产不输出生成的Spring默认密码。

公开详情核对：精确GET /campus-issues/{id}与/mutual-aid/posts/{id}是公开或所有者入口；GET /mutual-aid/posts/{id}/ratings继承目标帖子的可见权限，仅对已审核公开同校帖子允许游客。Task2只打开这几个精确GET入口，不打开其他子路径或写入；Task8/9必须在服务查询里判断对象的校园/审核/私密归属。

**幂等例外精确边界：** 登录/refresh/phone一次性换码/logout、admin认证/MFA/reauth、临时upload-intents/download-url/check-in-token及二进制上传有各自凭据机制；其他POST/PUT/DELETE业务都必需Idempotency-Key，8～128可打印ASCII字符，超过限制400。认证动作不产生持久幂等缓存里的原始token。固定路由例外列表，不接受客户端选择例外。

**角色矩阵：** user/guest不给admin权限；student认证由phone+verification决定而非只靠role。content_moderator有content.review/report.review/appeal.review；business_operator有workorder.read/process、issue.read/process；resource_admin有resource.read/write/process；campus_admin拥有本校运营权限（除security.investigate及platform.campus.manage）；platform_admin可配置校园管理但跨校操作仍需显式scope；security_investigator只有security.investigate/audit.read，不能仅因其他管理员角色获得真实匿名身份。新增operator赋权范围留Task3受控管理。

**数据库：** V7创建api_idempotency_records，应用生成BIGINT主键；唯一scope_digest+key_digest；request_digest、response_encrypted MEDIUMBLOB、response_type、status、created_at/expires_at，campus/user复合FK，范围索引。业务账号授权在DATABASE说明追加，不能自动给出数据库级全权。演示种子不得加载到生产，V1～V6不改。

- [ ] RED：OpaqueSessionTest验证伪造token无效、过期401、学生token不能admin、刷新重放拒绝、两次刷新仅一次成功、撤销旧access即时无效。
- [ ] RED：CurrentActorTest验证未登录401、未绑定/未认证403、跨namespace拒绝、当前DB已禁用用户不可凭旧会话访问。
- [ ] RED：受限身份普通业务403，但本人处罚、申诉与注销/数据请求仍可经明确的身份读取能力访问；没有有效会话仍401，已删除用户不可凭旧token访问。不能通过宽泛/me通配符放行其他写入。
- [ ] RED：IdempotencyExecutorTest在H2实际事务库验证同键同输入只创建一次业务记录、异请求409、业务异常不留下成功记录、权限撤销后不得重放敏感结果。
- [ ] RED：CursorCodecTest验证篡改、过滤或校园scope变化、过长游标及非法base64拒绝；分页上限100、默认20。
- [ ] RED：RateLimiterTest验证最大次数后429、窗口更新、Redis错误503。外部Redis使用适当adapter测试替身，Lua真实集成检查单独记录；不把替身测试称为Redis并发实测。
```java
@Test void refreshRejectsReusedToken() {
    SessionTokens first = sessions.issue(10001L, 1L, SessionKind.STUDENT);
    SessionTokens next = sessions.refresh(first.refreshToken(), SessionKind.STUDENT);
    assertThrows(BusinessException.class,
        () -> sessions.refresh(first.refreshToken(), SessionKind.STUDENT));
    assertTrue(sessions.authenticate(first.accessToken(), SessionKind.STUDENT).isEmpty());
    assertTrue(sessions.authenticate(next.accessToken(), SessionKind.STUDENT).isPresent());
}
```
- [ ] GREEN：按上述接口实现Redis adapter、Lua原子轮换与计数、数据库幂等服务、filter/aspect、安全链及当前用户工具。
- [ ] GREEN：聚焦测试修正后完整mvn test/package，记录RED/GREEN与未执行的真实Redis/MySQL检查，本地检查点不推送。

