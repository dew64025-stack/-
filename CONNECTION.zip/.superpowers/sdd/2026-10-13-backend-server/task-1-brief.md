## Task 1: 工程底座、响应、加密与ID

**Files:** backend/pom.xml；backend/src/main/java/com/caizhitong/CaizhitongApplication.java；common/和config/；backend/src/main/resources/application.yml；backend/src/test/java/com/caizhitong/common/；backend/README.md；.gitignore。

**Interfaces:** ApiResponse<T>有success/data/error/requestId/timestamp，null data/error不输出；ApiError有code/message/fieldErrors/retryable。BusinessException携带HttpStatus及稳定错误码，业务异常不泄露内部信息。SnowflakeIds(Clock,int workerId).nextId()线程安全、回拨拒绝、workerId范围0..1023。SensitiveDataCrypto(byte[] encryptionKey,byte[] hmacKey).encrypt(String purpose,String text)、decrypt(String purpose,byte[] cipher)、searchHash(String purpose,String text)。

- [ ] 配置Maven Java21和Boot4.1.1、MVC/Security/Validation/JPA/Redis/Flyway/MySQL/Actuator、测试H2/JUnit。不添加无用途依赖。
- [ ] RED：创建CryptoTest、SnowflakeIdsTest，运行mvn -f backend/pom.xml test；不存在的实现应导致预期失败，保存输出。
- [ ] GREEN：用AES-256-GCM随机12字节nonce、purpose作为AAD，格式version+nonce+ciphertext+tag；HMAC-SHA256独立密钥。错误不得回传密钥/原文。ID epoch为2026-01-01T00:00:00Z，41/10/12位，不使用数据库自增。
- [ ] GREEN：统一异常处理包含BeanValidation、未知字段拒绝、类型错误、409版本冲突、403/401，不输出堆栈/SQL。RequestIdFilter生成req_随机UUID，不信任入站requestId。
- [ ] 实现应用配置：UTC JDBC/Hibernate时区，ddl-auto=validate；Flyway使用独立迁移账号、baseline-on-migrate=false、clean-disabled=true；测试profile不运行MySQL迁移，禁止生产H2。
- [ ] 验证AES篡改/错purpose/错密钥拒绝、密文不相同、HMAC跨purpose不同、ID并发唯一和时钟回拨。
```java
@Test void tamperedCipherIsRejected() {
    var crypto = new SensitiveDataCrypto(new byte[32], new byte[32]);
    byte[] cipher = crypto.encrypt("phone", "13800000000");
    cipher[cipher.length - 1] ^= 1;
    assertThrows(IllegalArgumentException.class, () -> crypto.decrypt("phone", cipher));
}
```
- [ ] 运行完整已存在测试与mvn package；本地提交检查点，不推送。

